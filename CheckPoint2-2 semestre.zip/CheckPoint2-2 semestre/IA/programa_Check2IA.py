
import cv2
import os,sys, os.path
import numpy as np
from matplotlib import pyplot as plt
import math
import matplotlib.pyplot as plt
import math
import numpy

#filtro baixo
image_lower_hsv1 = np.array([130,130,100])
image_upper_hsv1 = np.array([180,255,255])
#filtro alto
image_lower_hsv2 = np.array([44/2 - 20, 80, 100]) 
image_upper_hsv2 = np.array([44/2 + 20, 255, 255])

def filtro_de_cor(img_bgr, low_hsv, high_hsv):
    """ RETORNA IMAGEM FILTRADA """
    img = cv2.cvtColor(img_bgr,cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(img, low_hsv, high_hsv)
    return mask 

def mascara_or(mask1, mask2):

    """ RETORNA A MASCARA OR"""
    mask = cv2.bitwise_or(mask1, mask2)
    return mask

def mascara_and(mask1, mask2):
     """ RETORNA A MASCARA END """
     mask = cv2.bitwise_and(mask1, mask2)
     
     return mask

def desenha_cruz(img, cX,cY, size, color):
     """ FAZENDO A CRUZ NO PONTO CX E CY """
     cv2.line(img,(cX - size,cY),(cX + size,cY),color,5)
     cv2.line(img,(cX,cY - size),(cX, cY + size),color,5)    

def escreve_texto(img, text, origem, color):
     """ FAZENDO A CRUZ NO PONTO CX E CY """
 
     font = cv2.FONT_HERSHEY_SIMPLEX
     
     cv2.putText(img, str(text), origem, font,1,color,2,cv2.LINE_AA)

def image_da_webcam(img):
    """
    ->>> !!!! FECHE A JANELA COM A TECLA ESC !!!! <<<<-
        deve receber a imagem da camera e retornar uma imagems filtrada.
    """  
    mask_hsv1 = filtro_de_cor(img, image_lower_hsv1, image_upper_hsv1)
    mask_hsv2 = filtro_de_cor(img, image_lower_hsv2, image_upper_hsv2)
    
    mask_hsv = mascara_or(mask_hsv1, mask_hsv2)
    
    contornos, _ = cv2.findContours(mask_hsv, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE) 

    mask_rgb = cv2.cvtColor(mask_hsv, cv2.COLOR_GRAY2RGB) 
    contornos_img = mask_rgb.copy()
    cnt = sorted(contornos, key=cv2.contourArea, reverse=True)
    maior = None
    maior_area = 0
    for c in contornos:
        area = cv2.contourArea(c)
        
        if area > maior_area:
            maior_area = area
            maior = c
            
    escreve_texto(contornos_img, maior_area, (250,250), (255,255,0))
    
    M = cv2.moments(cnt[0])
    M2 = cv2.moments(cnt[1])

    cX = int(M["m10"] / M["m00"])
    cY = int(M["m01"] / M["m00"])

    cX2 = int(M2["m10"] / M2["m00"])
    cY2 = int(M2["m01"] / M2["m00"])

    # Verifica se existe alguma para calcular, se sim calcula e exibe no display
    if M["m00"] != 0:
        cX = int(M["m10"] / M["m00"])
        cY = int(M["m01"] / M["m00"])

        cX2 = int(M2["m10"] / M2["m00"])
        cY2 = int(M2["m01"] / M2["m00"])

        size = 20
        color = (0,0,255)
       
        cv2.drawContours(contornos_img, cnt, 1, [255, 0, 0], 5)
        cv2.drawContours(contornos_img, cnt, 0, [255, 0, 0], 5)

        cv2.line(contornos_img,(cX - size,cY),(cX + size,cY),color,5)
        cv2.line(contornos_img,(cX,cY - size),(cX, cY + size),color,5)

        cv2.line(contornos_img,(cX2 - size,cY2),(cX2 + size,cY2),color,5)
        cv2.line(contornos_img,(cX2,cY2 - size),(cX2, cY2 + size),color,5)

        plt.plot([cX,cY2],[cY,cX2])
        
        texto = cY , cX
        origem = (0,50)
        escreve_texto(contornos_img, texto, origem, (0,255,0))

        cv2.line(contornos_img, ([cX,cY]),([cX2,cY2]),(128,128,0), 5 )

        y = (cY - cY2)
        x = (cX - cX2)
        angulo = math.atan2(y, x)
        print(angulo)
        print(numpy.degrees(angulo))

        

            
    else:
        cX, cY = 0, 0
        cX2, cY2 = 0, 0
        texto = ' '
        origem = (0,50)
        escreve_texto(contornos_img, texto, origem, (0,0,255))
    


    return contornos_img




cv2.namedWindow("preview")
vc = cv2.VideoCapture('simulacaoVideo.mp4')

vc.set(cv2.CAP_PROP_FRAME_WIDTH, 660)
vc.set(cv2.CAP_PROP_FRAME_HEIGHT, 500)

if vc.isOpened(): 
    rval, frame = vc.read()
else:
    rval = False

while rval:
    
    img = image_da_webcam(frame) 

    cv2.imshow("preview", img)
    cv2.imshow("original", frame)
    rval, frame = vc.read()
    key = cv2.waitKey(20)
    if key == 27: 
        break
cv2.destroyWindow("preview")
vc.release()
